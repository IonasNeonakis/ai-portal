document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['openrouter_key'], (result) => {
        if (result.openrouter_key) document.getElementById('apiKey').value = result.openrouter_key;
    });
});

document.getElementById('save').onclick = () => {
    const openrouter_key = document.getElementById('apiKey').value;

    chrome.storage.local.set({
        openrouter_key
    }, () => {
        const status = document.getElementById('status');
        status.textContent = 'Settings saved.';
        setTimeout(() => { status.textContent = ''; }, 2000);
    });
};
