console.log("GitLab MR Review Quiz extension loaded.");

let currentQuiz = null;
let currentMRData = null;
let originalApproveBtn = null;

function findApproveButton() {
    const buttons = Array.from(document.querySelectorAll('button'));
    return buttons.find(btn =>
        (btn.textContent.trim() === 'Approve' || btn.getAttribute('data-testid') === 'approve-button') &&
        !btn.closest('#mr-quiz-modal')
    );
}

async function getMRData() {
    const title = document.querySelector('.title')?.textContent?.trim() || "Unknown Title";
    const description = document.querySelector('.description')?.textContent?.trim() || "No description";

    let diff = "";
    try {
        // GitLab MR URLs look like: .../merge_requests/123
        // Fetching .../merge_requests/123.diff gives the raw diff
        const diffUrl = window.location.pathname + ".diff";
        const response = await fetch(diffUrl);
        if (response.ok) {
            diff = await response.text();
            // Truncate diff if it's too large for the model (e.g., 20k chars)
            if (diff.length > 20000) {
                diff = diff.substring(0, 20000) + "\n... (diff truncated)";
            }
        }
    } catch (e) {
        console.error("Failed to fetch MR diff:", e);
    }

    return { title, description, diff };
}

function handleApproveClick(event) {
    if (event.isTrusted && !currentQuiz) {
        console.log("Approve button clicked! Intercepting...");
        event.preventDefault();
        event.stopPropagation();
        originalApproveBtn = event.currentTarget;
        showQuizModal();
    }
}

async function showQuizModal() {
    if (document.getElementById('mr-quiz-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'mr-quiz-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <h2 class="modal-header">Review Quiz</h2>
            <div class="modal-body">
                <p id="quiz-loading">Fetching MR diff and generating quiz...</p>
                <div id="quiz-body" style="display: none;">
                    <div id="questions"></div>
                    <div id="quiz-error" style="color: red; margin: 10px 0; display: none;"></div>
                </div>
            </div>
            <div class="modal-footer" id="modal-footer" style="display: none;">
                <div class="button-group">
                    <button id="submit-quiz">Submit Answers</button>
                    <button id="close-modal-btn">Cancel</button>
                </div>
            </div>
            <button id="close-modal-x" class="close-x">Cancel</button>
        </div>
    `;
    document.body.appendChild(modal);

    const closeModal = () => {
        modal.remove();
        currentQuiz = null;
    };

    document.getElementById('close-modal-btn').onclick = closeModal;
    document.getElementById('close-modal-x').onclick = closeModal;

    const mrData = await getMRData();
    currentMRData = mrData;

    chrome.runtime.sendMessage({ action: "getQuizData", data: mrData }, (response) => {
        const loadingEl = document.getElementById('quiz-loading');
        const bodyEl = document.getElementById('quiz-body');
        const footerEl = document.getElementById('modal-footer');
        const questionsEl = document.getElementById('questions');

        if (response && response.questions) {
            currentQuiz = response;
            loadingEl.style.display = 'none';
            bodyEl.style.display = 'block';
            footerEl.style.display = 'block';

            response.questions.forEach((q, index) => {
                const qDiv = document.createElement('div');
                qDiv.className = 'question';
                qDiv.innerHTML = `
                    <p>Q${index + 1}: ${q.question}</p>
                    ${q.options.map((opt, i) => `
                        <label>
                            <input type="radio" name="q${index}" value="${i}"> <span>${opt}</span>
                        </label>
                    `).join('')}
                `;
                questionsEl.appendChild(qDiv);
            });
        } else {
            loadingEl.textContent = "Error generating quiz: " + (response?.error || "Unknown error");
        }
    });

    document.getElementById('submit-quiz').onclick = () => {
        const answers = [];
        let allAnswered = true;
        currentQuiz.questions.forEach((_, index) => {
            const selected = document.querySelector(`input[name="q${index}"]:checked`);
            if (selected) {
                answers.push(parseInt(selected.value));
            } else {
                allAnswered = false;
            }
        });

        if (!allAnswered) {
            const errorEl = document.getElementById('quiz-error');
            errorEl.textContent = "Please answer all questions.";
            errorEl.style.display = 'block';
            return;
        }

        validateQuiz(answers);
    };
}

function validateQuiz(userAnswers) {
    const totalQuestions = currentQuiz.questions.length;
    let correctCount = 0;

    userAnswers.forEach((ans, i) => {
        if (ans === currentQuiz.questions[i].correct) {
            correctCount++;
        }
    });

    if (correctCount === totalQuestions) {
        alert("Correct! You have carefully reviewed the changes.");
        document.getElementById('mr-quiz-modal').remove();
        // Trigger the original approval
        if (originalApproveBtn) {
            originalApproveBtn.click();
        }
    } else {
        alert("Incorrect answers. A notification has been sent.");

        // Construct detailed report
        let quizReportHtml = "<ul>";
        currentQuiz.questions.forEach((q, i) => {
            const userAnsIndex = userAnswers[i];
            const correctAnsIndex = q.correct;
            const userAnsText = q.options[userAnsIndex];
            const correctAnsText = q.options[correctAnsIndex];

            quizReportHtml += `<li style="margin-bottom: 15px;">
                <strong>Question:</strong> ${q.question}<br>`;

            if (userAnsIndex === correctAnsIndex) {
                quizReportHtml += `<span style="color: green;">Correct Answer: ${correctAnsText}</span>`;
            } else {
                quizReportHtml += `<span style="color: red; text-decoration: line-through;">Your Answer: ${userAnsText}</span><br>
                                   <span style="color: green;">Correct Answer: ${correctAnsText}</span>`;
            }
            quizReportHtml += `</li>`;
        });
        quizReportHtml += "</ul>";

        chrome.runtime.sendMessage({
            action: "notifyFailure",
            data: {
                correct: correctCount,
                total: totalQuestions,
                mrTitle: currentMRData.title,
                quizReportHtml: quizReportHtml
            }
        });
        document.getElementById('mr-quiz-modal').remove();
        currentQuiz = null;
    }
}

const observer = new MutationObserver(() => {
    const approveBtn = findApproveButton();
    if (approveBtn && !approveBtn.hasAttribute('data-quiz-intercepted')) {
        approveBtn.setAttribute('data-quiz-intercepted', 'true');
        approveBtn.addEventListener('click', handleApproveClick, true);
    }
});

observer.observe(document.body, { childList: true, subtree: true });
