const OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions";
const MODEL = "anthropic/claude-3.5-sonnet";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getQuizData") {
        generateQuizOpenRouter(request.data)
            .then(data => sendResponse(data))
            .catch(err => {
                console.error("Quiz generation failed:", err);
                sendResponse({ error: err.message });
            });
        return true;
    }

    if (request.action === "notifyFailure") {
        sendEmailNotification(request.data);
        return true;
    }
});

async function generateQuizOpenRouter(mrData) {
    const { openrouter_key } = await chrome.storage.local.get("openrouter_key");

    if (!openrouter_key) {
        return {
            questions: [
                {
                    question: `[MOCK] No API Key found. What is the title of this MR?`,
                    options: [mrData.title, "Wrong Title", "Secret Project"],
                    correct: 0
                },
                {
                    question: `[MOCK] MR Description check: ${mrData.description.substring(0, 20)}...`,
                    options: ["Correct description", "Invalid content", "Is this real?"],
                    correct: 0
                },
                {
                    question: `[MOCK] No API Key found. What is the title of this MR?`,
                    options: [mrData.title, "Wrong Title", "Secret Project"],
                    correct: 0
                },
                {
                    question: `[MOCK] No API Key found. What is the title of this MR?`,
                    options: [mrData.title, "Wrong Title", "Secret Project"],
                    correct: 0
                },
            ]
        };
    }

    const prompt = `
        You are a code reviewer's assistant. Based on the following GitLab Merge Request information and its raw code diff, create a 3-question multiple-choice quiz to verify the reviewer has actually read and understood the code changes.
        
        Focus the questions on specific logic changes, bug fixes, or architectural shifts visible in the diff.
        
        MR Title: ${mrData.title}
        MR Description: ${mrData.description}
        
        CODE DIFF:
        ${mrData.diff}
        
        Format your response as a strict JSON object (no other text):
        {
          "questions": [
            {
              "question": "A specific question about the code changes",
              "options": ["Option A", "Option B", "Option C"],
              "correct": 0
            }
          ]
        }
    `;

    const response = await fetch(OPENROUTER_API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${openrouter_key}`,
            "HTTP-Referer": "https://github.com/gitlab-quiz-extension", // Required by OpenRouter
            "X-Title": "GitLab MR Review Quiz"
        },
        body: JSON.stringify({
            model: MODEL,
            messages: [{ role: "user", content: prompt }]
        })
    });

    const result = await response.json();
    if (result.error) throw new Error(result.error.message || "OpenRouter error");

    const text = result.choices[0].message.content;
    const jsonStr = text.replace(/```json|```/g, "").trim();
    return JSON.parse(jsonStr);
}

const EMAILJS_SERVICE_ID = "service_t5k64bs";
const EMAILJS_TEMPLATE_ID = "template_olpxb3t";
const EMAILJS_PUBLIC_KEY = "tJqXMBZAynnsztCFR";

async function sendEmailNotification(data) {
    const emailData = {
        service_id: EMAILJS_SERVICE_ID,
        template_id: EMAILJS_TEMPLATE_ID,
        user_id: EMAILJS_PUBLIC_KEY,
        template_params: {
            mr_title: data.mrTitle,
            user_score: `${data.correct}/${data.total}`,
            quiz_report: data.quizReportHtml,
            recipient: "ineonakis+review@takima.fr"
        }
    };

    try {
        const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(emailData)
        });

        if (response.ok) {
            console.log("[NOTIFICATION] Email sent successfully via EmailJS.");
        } else {
            const errorText = await response.text();
            console.error("[NOTIFICATION] EmailJS failed:", errorText);
        }
    } catch (err) {
        console.error("[NOTIFICATION] Error calling EmailJS:", err);
    }
}
